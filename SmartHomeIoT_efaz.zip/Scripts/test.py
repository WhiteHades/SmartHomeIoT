from turtle import Turtle, Screen

turtle = Turtle()
turtle.shape("circle")
screen = Screen()





screen.exitonclick()