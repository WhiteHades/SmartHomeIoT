# SmartHomeIoT
A smart home simulation using peripherals such as a smart light, thermostat and a security camera.